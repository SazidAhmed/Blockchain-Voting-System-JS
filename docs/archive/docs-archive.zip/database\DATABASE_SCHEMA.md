# Database Schema Documentation

## Overview

The University Blockchain Voting System uses MySQL as its relational database for storing off-chain metadata, user profiles, and audit trails. **Critical vote data is stored encrypted and on the blockchain**, while this database holds supporting information.

## Security Principles

1. **Minimal PII Storage**: Only essential personal information is stored, encrypted where possible
2. **Pseudonymous On-Chain Identity**: Users have a `pseudonym_id` used on-chain, separate from `institution_id`
3. **Encrypted Sensitive Data**: PII stored in `encrypted_profile_blob`
4. **Tamper-Evident Logging**: `audit_logs` table uses hash chaining
5. **No Plaintext Ballots**: Only encrypted ballots and nullifiers stored

## Database Schema (v1.0)

### Core Tables

#### `users`

Stores registered voters and administrators.

**Columns:**

| Column                   | Type                     | Description                                                      |
| ------------------------ | ------------------------ | ---------------------------------------------------------------- |
| `id`                     | INT (PK, AUTO_INCREMENT) | Primary key                                                      |
| `institution_id`         | VARCHAR(50) UNIQUE       | University student/employee ID                                   |
| `username`               | VARCHAR(100)             | Login username                                                   |
| `password`               | VARCHAR(255)             | Bcrypt hashed password                                           |
| `role`                   | ENUM                     | student, teacher, staff, board_member, admin                     |
| `email`                  | VARCHAR(100) UNIQUE      | Email address                                                    |
| `public_key`             | TEXT                     | User's public ECDSA P-256 key                                    |
| `pseudonym_id`           | VARCHAR(64) UNIQUE       | SHA256 hash for on-chain identity (unlinkable to institution_id) |
| `encrypted_profile_blob` | TEXT                     | AES-256-GCM encrypted PII                                        |
| `registration_status`    | ENUM                     | pending, verified, active, suspended                             |
| `mfa_enabled`            | BOOLEAN                  | Whether MFA is enabled                                           |
| `mfa_secret`             | VARCHAR(255)             | Encrypted TOTP secret                                            |
| `encryption_public_key`  | TEXT                     | RSA-OAEP public key for encrypting ballots                       |
| `created_at`             | TIMESTAMP                | Account creation time                                            |
| `updated_at`             | TIMESTAMP                | Last update time (auto-updates)                                  |
| `last_login`             | TIMESTAMP NULL           | Last login timestamp                                             |

**Indexes:** `institution_id`, `email`, `pseudonym_id`, `role`, `registration_status`

#### `elections`

Election configurations and cryptographic parameters.

**Columns:**

| Column               | Type                     | Description                                     |
| -------------------- | ------------------------ | ----------------------------------------------- |
| `id`                 | INT (PK, AUTO_INCREMENT) | Primary key                                     |
| `title`              | VARCHAR(255)             | Election title                                  |
| `description`        | TEXT                     | Election description                            |
| `start_date`         | DATETIME                 | Voting window start                             |
| `end_date`           | DATETIME                 | Voting window end                               |
| `status`             | ENUM                     | pending, active, completed, cancelled, tallying |
| `public_key`         | TEXT                     | Threshold encryption public key (ElGamal)       |
| `threshold_params`   | JSON                     | Threshold parameters {t, n, shares}             |
| `eligible_roles`     | JSON                     | Array of roles allowed to vote                  |
| `created_by`         | INT NOT NULL             | FK to users.id (admin who created)              |
| `created_at`         | TIMESTAMP                | Creation time                                   |
| `updated_at`         | TIMESTAMP                | Last update time (auto-updates)                 |
| `tally_completed_at` | TIMESTAMP NULL           | When tally finished                             |
| `results_hash`       | VARCHAR(64)              | SHA256 of final tally for verification          |
| `is_locked`          | BOOLEAN                  | Locked for editing                              |
| `locked_at`          | TIMESTAMP NULL           | When locked                                     |
| `locked_by`          | INT NULL                 | FK to users.id — who locked it                  |

#### `candidates`

Candidates for each election.

**Columns:**

| Column          | Type                     | Description               |
| --------------- | ------------------------ | ------------------------- |
| `id`            | INT (PK, AUTO_INCREMENT) | Primary key               |
| `election_id`   | INT NOT NULL             | FK to elections.id        |
| `name`          | VARCHAR(255)             | Candidate name            |
| `description`   | TEXT                     | Candidate description     |
| `metadata`      | JSON                     | Additional candidate data |
| `display_order` | INT                      | Sort order for UI         |
| `is_locked`     | BOOLEAN                  | Locked for editing        |
| `locked_at`     | TIMESTAMP NULL           | When locked               |
| `created_at`    | TIMESTAMP                | Creation time             |

#### `blind_tokens`

Blind-signed eligibility tokens (privacy-preserving).

**Columns:**

| Column              | Type                     | Description                                        |
| ------------------- | ------------------------ | -------------------------------------------------- |
| `id`                | INT (PK, AUTO_INCREMENT) | Primary key                                        |
| `token_id_hash`     | VARCHAR(64) UNIQUE       | SHA256 of token (not the actual token)             |
| `pseudonym_id`      | VARCHAR(64)              | Links to users.pseudonym_id                        |
| `election_id`       | INT NOT NULL             | FK to elections.id — token valid for this election |
| `issued_at`         | TIMESTAMP                | When token was issued                              |
| `revoked`           | BOOLEAN                  | Revocation status                                  |
| `revoked_at`        | TIMESTAMP NULL           | When revoked                                       |
| `revocation_reason` | VARCHAR(255)             | Reason for revocation                              |
| `blind_signature`   | TEXT                     | Signed blinded token (base64)                      |

**Privacy Note:** The server never sees the unblinded token, ensuring voter anonymity.

#### `voter_registrations`

Tracks voter registration status.

**Key Fields:**

- `user_id`, `election_id` - Unique constraint
- `status` - registered | voted | revoked
- `registration_token` - Legacy token (prefer blind_tokens)
- `voted_at` - Timestamp when vote was cast

#### `votes_meta`

On-chain vote metadata and nullifiers (no ballot content).

**Key Fields:**

- `tx_hash` - Blockchain transaction hash (unique)
- `block_index` - Block number where included
- `election_id` - Election reference
- `nullifier_hash` - SHA256 of nullifier (prevents double voting)
- `encrypted_ballot` - Threshold-encrypted ballot data
- `signature` - ECDSA signature of the vote package
- `voter_public_key` - Public key used for signature verification (unlinkable to user)
- `merkle_root`, `merkle_proof` - For verification

**Privacy Note:** Nullifier prevents double voting without revealing voter identity.

#### `vote_receipts`

Cryptographic receipts issued to voters.

**Columns:**

| Column                 | Type                     | Description                       |
| ---------------------- | ------------------------ | --------------------------------- |
| `id`                   | INT (PK, AUTO_INCREMENT) | Primary key                       |
| `election_id`          | INT                      | FK to elections.id                |
| `nullifier_hash`       | VARCHAR(64)              | Allows voter to verify their vote |
| `transaction_hash`     | VARCHAR(64)              | Transaction ID on blockchain      |
| `block_height`         | INT                      | Block number                      |
| `block_hash`           | VARCHAR(64)              | Block hash                        |
| `merkle_proof`         | JSON                     | Merkle inclusion proof            |
| `validator_signatures` | JSON                     | Array of validator signatures     |
| `issued_at`            | TIMESTAMP                | When receipt was issued           |

**Usage:** Voters can use their nullifier and this receipt to verify their vote was counted.

### Blockchain Network Tables

#### `nodes`

Validator and observer nodes in the permissioned network.

**Columns:**

| Column                   | Type                     | Description                                |
| ------------------------ | ------------------------ | ------------------------------------------ |
| `id`                     | INT (PK, AUTO_INCREMENT) | Primary key                                |
| `node_id`                | VARCHAR(64) UNIQUE       | Unique node identifier                     |
| `pubkey`                 | TEXT                     | Node public key for validation             |
| `endpoint`               | VARCHAR(255)             | API endpoint (host:port)                   |
| `p2p_endpoint`           | VARCHAR(255) NULL        | P2P connection endpoint                    |
| `node_type`              | ENUM                     | validator, observer, seed                  |
| `status`                 | ENUM                     | active, inactive, quarantined, removed     |
| `added_by`               | INT NULL                 | FK to users.id — admin who added this node |
| `approved_at`            | TIMESTAMP NULL           | When node was approved                     |
| `quorum_votes`           | JSON                     | Votes from other validators for approval   |
| `last_seen`              | TIMESTAMP NULL           | Health monitoring timestamp                |
| `last_block_validated`   | INT NULL                 | Last block this node validated             |
| `blocks_validated_count` | INT                      | Total blocks validated                     |
| `misbehavior_count`      | INT                      | Number of misbehavior reports              |
| `evidence`               | JSON                     | Array of misbehavior evidence              |
| `quarantined_at`         | TIMESTAMP NULL           | When quarantined                           |
| `quarantine_reason`      | VARCHAR(255)             | Reason for quarantine                      |
| `created_at`             | TIMESTAMP                | Record creation time                       |
| `updated_at`             | TIMESTAMP                | Last update (auto-updates)                 |

**Governance:** Nodes can be quarantined or removed based on evidence and quorum votes.

#### `threshold_key_shares`

Metadata about distributed key shares (actual shares in HSM/Vault).

**Columns:**

| Column                    | Type                     | Description                          |
| ------------------------- | ------------------------ | ------------------------------------ |
| `id`                      | INT (PK, AUTO_INCREMENT) | Primary key                          |
| `election_id`             | INT NOT NULL             | FK to elections.id                   |
| `node_id`                 | VARCHAR(64)              | Node holding this share              |
| `share_index`             | INT                      | Index (1 to n)                       |
| `public_verification_key` | TEXT NULL                | Public key for verifying this share  |
| `ceremony_id`             | VARCHAR(64) NULL         | DKG ceremony identifier              |
| `ceremony_completed_at`   | TIMESTAMP NULL           | When DKG ceremony finished           |
| `status`                  | ENUM                     | pending, active, revoked, rotated    |
| `vault_path`              | VARCHAR(255) NULL        | Path to encrypted share in Vault/HSM |
| `created_at`              | TIMESTAMP                | Record creation time                 |

**Security Note:** Actual key shares are NEVER stored in this database. Only metadata.

#### `tally_partial_decryptions`

Partial decryptions from validators during tallying.

**Columns:**

| Column                 | Type                     | Description                         |
| ---------------------- | ------------------------ | ----------------------------------- |
| `id`                   | INT (PK, AUTO_INCREMENT) | Primary key                         |
| `election_id`          | INT NOT NULL             | FK to elections.id                  |
| `vote_meta_id`         | INT NOT NULL             | FK to votes_meta.id                 |
| `node_id`              | VARCHAR(64)              | Validator providing decryption      |
| `partial_decryption`   | TEXT                     | Base64 encoded partial decryption   |
| `proof_of_correctness` | TEXT NULL                | ZK proof that decryption is correct |
| `signature`            | TEXT NULL                | Validator signature                 |
| `created_at`           | TIMESTAMP                | Record creation time                |

**Process:** Threshold decryption requires t-of-n validators to provide partial decryptions.

### Audit and Configuration Tables

#### `audit_logs`

Tamper-evident audit trail using hash chaining.

**Key Fields:**

- `event_type` - e.g., USER_REGISTERED, VOTE_CAST
- `event_category` - auth | vote | election | node | admin | security
- `user_id`, `ip_address`, `user_agent` - Actor information
- `details` - JSON event details
- `previous_hash` - Hash of previous log entry (tamper-evident chain)
- `log_hash` - Hash of this entry

**Tamper Evidence:** Each log entry includes the hash of the previous entry, creating a chain.

#### `system_config`

Global system configuration.

**Columns:**

| Column         | Type                     | Description                       |
| -------------- | ------------------------ | --------------------------------- |
| `id`           | INT (PK, AUTO_INCREMENT) | Primary key                       |
| `config_key`   | VARCHAR(100) UNIQUE      | Configuration parameter name      |
| `config_value` | TEXT                     | Value (potentially encrypted)     |
| `config_type`  | ENUM                     | string, number, boolean, json     |
| `description`  | TEXT                     | Human-readable description        |
| `is_encrypted` | BOOLEAN                  | Whether value is encrypted        |
| `updated_at`   | TIMESTAMP                | Last update time (auto-updates)   |
| `updated_by`   | INT NULL                 | FK to users.id — who last updated |

**Examples:**

- `consensus_type`: pbft | tendermint | raft
- `min_validators`: Minimum validator count
- `threshold_t`, `threshold_n`: Threshold parameters

#### `admin_audit_logs`

Admin action tracking for the admin panel.

**Columns:**

| Column             | Type                     | Description                                 |
| ------------------ | ------------------------ | ------------------------------------------- |
| `id`               | INT (PK, AUTO_INCREMENT) | Primary key                                 |
| `admin_id`         | INT NOT NULL             | FK to users.id — admin who performed action |
| `action_type`      | VARCHAR(50)              | e.g., CREATE_ELECTION, ADD_CANDIDATE        |
| `resource_type`    | VARCHAR(50)              | e.g., election, candidate                   |
| `resource_id`      | INT NULL                 | ID of the affected resource                 |
| `changes`          | LONGTEXT                 | JSON diff of changes made                   |
| `change_hash`      | VARCHAR(64)              | SHA256 hash of changes                      |
| `action_signature` | VARCHAR(64)              | ECDSA signature of action                   |
| `reason`           | VARCHAR(500)             | Reason for the action                       |
| `ip_address`       | VARCHAR(45)              | Admin's IP address                          |
| `user_agent`       | TEXT                     | Admin's browser/client info                 |
| `metadata`         | JSON                     | Additional event data                       |
| `timestamp`        | DATETIME                 | When action occurred                        |
| `status`           | ENUM                     | success, failed                             |
| `verified`         | BOOLEAN                  | Whether signature was verified              |
| `created_at`       | TIMESTAMP                | Record creation time                        |

#### `admin_security_logs`

Security-relevant events for admin monitoring.

**Columns:**

| Column            | Type                     | Description                             |
| ----------------- | ------------------------ | --------------------------------------- |
| `id`              | INT (PK, AUTO_INCREMENT) | Primary key                             |
| `admin_id`        | INT NOT NULL             | FK to users.id                          |
| `event_type`      | VARCHAR(50)              | e.g., FAILED_LOGIN, SUSPICIOUS_ACTIVITY |
| `severity`        | ENUM                     | LOW, MEDIUM, HIGH, CRITICAL             |
| `description`     | VARCHAR(500)             | Event description                       |
| `metadata`        | JSON                     | Additional event data                   |
| `timestamp`       | DATETIME                 | When event occurred                     |
| `acknowledged`    | BOOLEAN                  | Whether acknowledged by another admin   |
| `acknowledged_by` | INT NULL                 | FK to users.id — who acknowledged       |
| `acknowledged_at` | DATETIME NULL            | When acknowledged                       |
| `created_at`      | TIMESTAMP                | Record creation time                    |

#### `schema_migrations`

Tracks applied database migrations.

**Key Fields:**

- `migration_name` - Migration file name
- `applied_at` - Timestamp
- `checksum` - SHA256 of migration file

## Views

### `v_active_elections`

Convenient view for active/pending elections with counts.

**Columns:**

- Basic election info
- `candidate_count` - Number of candidates
- `registered_voters` - Number of registered voters
- `votes_cast` - Number of votes received

### `admin_activity_summary`

Admin activity summary for monitoring dashboards.

**Columns:**

| Column                  | Type         | Description                     |
| ----------------------- | ------------ | ------------------------------- |
| `id`                    | INT          | Admin user ID                   |
| `username`              | VARCHAR(100) | Admin username                  |
| `email`                 | VARCHAR(100) | Admin email                     |
| `elections_created`     | INT          | Count of elections created      |
| `candidates_added`      | INT          | Count of candidates added       |
| `candidates_deleted`    | INT          | Count of candidates deleted     |
| `elections_activated`   | INT          | Count of elections activated    |
| `elections_deactivated` | INT          | Count of elections deactivated  |
| `failed_actions`        | INT          | Count of failed admin actions   |
| `last_action`           | TIMESTAMP    | Timestamp of most recent action |

### `v_node_health`

Node health monitoring view.

**Columns:**

- Node identification and status
- `minutes_since_last_seen` - Time since last heartbeat
- `health_status` - healthy | degraded | offline | quarantined | removed

## Data Flow Examples

### 1. User Registration Flow

```sql
-- 1. Create user
INSERT INTO users (institution_id, username, password, role, email,
                   pseudonym_id, public_key, registration_status)
VALUES (?, ?, ?, ?, ?, ?, ?, 'pending');

-- 2. After IdP verification
UPDATE users SET registration_status = 'verified' WHERE id = ?;

-- 3. Issue blind token
INSERT INTO blind_tokens (token_id_hash, pseudonym_id, election_id, blind_signature)
VALUES (?, ?, ?, ?);
```

### 2. Vote Casting Flow

```sql
-- 1. Check if user is registered for election
SELECT * FROM voter_registrations
WHERE user_id = ? AND election_id = ? AND status = 'registered';

-- 2. Check nullifier hasn't been used
SELECT * FROM votes_meta WHERE nullifier_hash = ?;

-- 3. Store vote metadata (after blockchain inclusion)
INSERT INTO votes_meta (tx_hash, block_index, election_id, nullifier_hash,
                        encrypted_ballot, merkle_proof)
VALUES (?, ?, ?, ?, ?, ?);

-- 4. Update registration status
UPDATE voter_registrations SET status = 'voted', voted_at = NOW()
WHERE user_id = ? AND election_id = ?;

-- 5. Issue receipt
INSERT INTO vote_receipts (election_id, nullifier_hash, transaction_hash,
                           block_height, merkle_proof, validator_signatures)
VALUES (?, ?, ?, ?, ?, ?);

-- 6. Log event
INSERT INTO audit_logs (event_type, event_category, user_id, target_type,
                        target_id, details, previous_hash, log_hash)
VALUES ('VOTE_CAST', 'vote', ?, 'election', ?, ?, ?, ?);
```

### 3. Tally Process

```sql
-- 1. Get all votes for election
SELECT * FROM votes_meta WHERE election_id = ?;

-- 2. Collect partial decryptions from validators
INSERT INTO tally_partial_decryptions
  (election_id, vote_meta_id, node_id, partial_decryption, proof_of_correctness)
VALUES (?, ?, ?, ?, ?);

-- 3. After combining t-of-n shares, update election
UPDATE elections
SET status = 'completed',
    tally_completed_at = NOW(),
    results_hash = ?
WHERE id = ?;
```

## Indexes and Performance

### Critical Indexes

- `votes_meta.nullifier_hash` - Fast double-vote prevention
- `votes_meta.tx_hash` - Receipt verification
- `votes_meta.election_id` - Tallying queries
- `audit_logs.timestamp` - Audit queries
- `nodes.last_seen` - Health monitoring

### Composite Indexes

- `voter_registrations(user_id, election_id)` - Unique constraint
- `threshold_key_shares(election_id, node_id, share_index)` - Unique constraint

## Security Considerations

### Encryption

- User passwords: bcrypt (hash only)
- `encrypted_profile_blob`: AES-256-GCM
- `mfa_secret`: AES-256-GCM
- Key shares: Stored in HSM/Vault, NOT in database

### Access Control

- Application uses connection pool with limited privileges
- No direct database access for users
- Prepared statements prevent SQL injection
- Audit logs track all data access

### Privacy Protection

1. **Pseudonymity**: `pseudonym_id` used on-chain, unlinkable to `institution_id`
2. **Blind Tokens**: Server never sees unblinded tokens
3. **Nullifiers**: Prevent double voting without revealing identity
4. **Encrypted Ballots**: Only threshold decryption reveals vote content

## Backup and Recovery

### Backup Strategy

- Daily full backups of entire database
- Transaction log backups every hour
- Backup retention: 90 days
- Encrypted backups stored in multiple regions

### Critical Tables (Priority 1)

- `votes_meta` - Vote records
- `vote_receipts` - Voter receipts
- `audit_logs` - Audit trail
- `elections` - Election config

### Recoverable Tables (Priority 2)

- `users` - Can be recreated from IdP
- `candidates` - Can be recreated from admin input

## Migration Management

### Running Migrations

```bash
# Run all pending migrations
node services/backend/scripts/migrate.js run

# Check migration status
node services/backend/scripts/migrate.js status

# Rollback last migration (when implemented)
node services/backend/scripts/migrate.js rollback
```

### Creating New Migrations

1. Create file: `services/backend/migrations/00X_description.sql`
2. Use sequential numbering: 001, 002, 003...
3. Include idempotent statements (CREATE TABLE IF NOT EXISTS)
4. Test migration on staging database first

## Monitoring Queries

### Check vote counts by election

```sql
SELECT
    e.id, e.title, e.status,
    COUNT(vm.id) as vote_count
FROM elections e
LEFT JOIN votes_meta vm ON e.id = vm.election_id
GROUP BY e.id, e.title, e.status;
```

### Check validator health

```sql
SELECT * FROM v_node_health WHERE health_status != 'healthy';
```

### Recent audit events

```sql
SELECT event_type, event_category, user_id, timestamp, details
FROM audit_logs
WHERE severity IN ('error', 'critical')
ORDER BY timestamp DESC
LIMIT 50;
```

### Detect potential double voting attempts

```sql
SELECT nullifier_hash, COUNT(*) as attempts
FROM audit_logs
WHERE event_type = 'VOTE_ATTEMPT_FAILED'
  AND details->>'$.reason' = 'nullifier_already_used'
GROUP BY nullifier_hash
HAVING attempts > 1;
```

## Future Enhancements

- [ ] Database sharding for horizontal scaling
- [ ] Read replicas for query performance
- [ ] Automated backup verification
- [ ] Migration rollback support
- [ ] Database encryption at rest
- [ ] Connection pooling optimization
- [ ] Query performance monitoring
- [ ] Automated index optimization

---

**Last Updated:** 2026-07-15  
**Schema Version:** 1.1  
**Migration File:** 001_initial_schema.sql
